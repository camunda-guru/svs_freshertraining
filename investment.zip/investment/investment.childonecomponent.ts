import { Component,Input,Output,EventEmitter } 
from "../../node_modules/@angular/core";


@Component({
	selector: 'child-one',
	templateUrl:'./app/investment/investment.childonecomponent.html',
	styleUrls:['./app/investment/investment.childonecomponent.css']
    
})
export class ChildOneComponent {
	@Input() 
	childReceiptType : string; 
	@Input()
	childCertificateDate:Date;
	@Input()
	childTenure:string;
	@Input()
	childInvestmentType:string;
	@Input()
	childInvestmentAmount:number;
	@Input()
	childMaturityDate:Date;
	@Input()
	childMaturityInstructions:string;	
  	@Output('addInvestment') 
	addInvestmentEvent = new EventEmitter<any>();

  		
	addChildInvestment() {
	      this.addInvestmentEvent.emit();
        }	
		
} 

