import {NgModule} from "@angular/core";
import {Routes, RouterModule} from "@angular/router";
import { CustomerComponent } from "./customer/customer.component";
import { LienComponent } from "./lien/lien.component";
import { UserComponent } from "./user/user.component";
import { InvestmentComponent } from "./investment/investment.component";



const routes:Routes=[{
    path: 'Customers',
    component: CustomerComponent
},
  {
path: 'Lien',
component: LienComponent
} ,
{
    path: 'Users',
    component: UserComponent
    },
    {
        path: 'Investments',
        component: InvestmentComponent
        }   
    
];

@NgModule({
    imports:[RouterModule.forRoot(routes)],
    exports:[RouterModule]
})
export class AppRoutingModule
{
}
