import { Component } from "../node_modules/@angular/core";

@Component({
    selector:'customer-details',
    templateUrl:'./app/app.component.html',
    styleUrls:['./app/app.component.css']
})
export class AppComponent
{

}