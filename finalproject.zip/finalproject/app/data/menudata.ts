export var menuData:string[]=
["Customers","Investments","Payments",
"Lien","Users"]