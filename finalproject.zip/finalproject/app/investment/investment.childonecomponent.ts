import { Component,Input,Output,EventEmitter, OnInit } 
from "../../node_modules/@angular/core";


@Component({
	selector: 'child-one',
	templateUrl:'./app/investment/investment.childonecomponent.html',
	styleUrls:['./app/investment/investment.childonecomponent.css']
    
})
export class ChildOneComponent implements OnInit{
	@Input() 
	childReceiptType : string; 
	@Input()
	childCertificateDate:Date;
	@Input()
	childTenure:string;
	@Input()
	childInvestmentType:string;
	@Input()
	childInvestmentAmount:number;
	@Input()
	childMaturityDate:Date;
	@Input()
	childMaturityInstructions:string;	
  	@Output('addInvestment') 
	addInvestmentEvent = new EventEmitter<any>();
	private cdate:string;
	private mdate:string;
		  
	ngOnInit()
	{
		console.log(this.childCertificateDate);
		if(this.childCertificateDate.getFullYear()>0)
		{  //certicate date
		   this.cdate=this.childCertificateDate.getDate()+"/"+
		   this.childCertificateDate.getMonth()+"/"+
		   this.childCertificateDate.getFullYear();
        //maturity date
		   this.mdate=this.childMaturityDate.getDate()+"/"+
		   this.childMaturityDate.getMonth()+"/"+
		   this.childMaturityDate.getFullYear();
		   
		}
	}
	addChildInvestment() {
	      this.addInvestmentEvent.emit();
        }	
		
} 

