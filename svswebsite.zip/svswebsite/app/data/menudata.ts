export var menuData:string[]=
["Customers","Investments","Payments",
"BalanceSheet"]