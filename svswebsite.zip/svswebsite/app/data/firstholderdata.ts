export enum gender{MALE,FEMALE};
//var genderInfo:gender=gender.MALE;
export var firstHolderData:any={
   
    fullName:"Anoop",
    dob:new Date(1987,2,2),
    email:"anoop@gmail.com",
    phoneNo:9956789345,
    pancardNo:"ASIPN6789N",
    aadharCardNo:554466778899,
    gdata:gender.MALE,
    photoPath:"./app/images/magical-lata.jpg",
    empCode:4875436

}