import { NgModule } from "../node_modules/@angular/core";
import { CommonModule } from "../node_modules/@angular/common";
import { BrowserModule } from "../node_modules/@angular/platform-browser";
import { AppComponent } from "./app.component";
import { FirstHolderComponent } from "./firstholder/firstholder.component";
import { FirstHolderService } from "./services/firstholderservice";
import {

    MatAutocompleteModule,
    MatButtonModule,
    MatButtonToggleModule,
    MatCardModule,
    MatCheckboxModule,
    MatChipsModule,
    MatDatepickerModule,
    MatDialogModule,
    MatExpansionModule,  MatFormFieldModule,
    MatGridListModule,
    MatIconModule,
    MatInputModule,
    MatListModule,
    MatMenuModule,
    MatNativeDateModule,
    MatPaginatorModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatRadioModule,
    MatRippleModule,
    MatSelectModule,
    MatSidenavModule,
    MatSliderModule,
    MatSlideToggleModule,
    MatSnackBarModule,
    MatSortModule,
    MatStepperModule,
   
    MatTableModule,
    MatTabsModule,
    MatToolbarModule,
    MatTooltipModule,
} from '@angular/material'
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import { MenuComponent } from "./menu/menu.component";
import { MenuService } from "./services/menuservice";
import { AppRoutingModule } from "./app.routing.module";
import { CustomerComponent } from "./customer/customer.component";
@NgModule({

    imports:[CommonModule,BrowserModule, MatTableModule,
        MatTabsModule,BrowserAnimationsModule, MatIconModule,AppRoutingModule],
    declarations:[AppComponent,FirstHolderComponent,MenuComponent,CustomerComponent],
    providers:[FirstHolderService,MenuService],
    bootstrap:[AppComponent]

})
export class AppModule
{

}