import { Component, OnInit } from "../../node_modules/@angular/core";
import {gender} from "../data/firstholderdata"
import { FirstHolderService } from "../services/firstholderservice";
@Component(
    {
        selector:'first-holder',
        templateUrl:'./app/firstholder/firstholder.component.html',
        styleUrls:['./app/firstholder/firstholder.component.css']
    }
)
export class FirstHolderComponent implements OnInit
{
    private fullName:string;
    private dob:string;
    private genderData:string;
    private phoneNo:number;
    private email:string;
    private panNo:string;
    private aadharNo:number;
    private photoPath:string;
    private empCode:string;
    constructor(private obj:FirstHolderService)
    {
       
    }

    ngOnInit()
    {
        this.obj.getFirstHolderData().then(response=>
        {
            this.fullName=response.fullName;
            var year=response.dob.getYear()+1900;
            var month=response.dob.getMonth();
            var day=response.dob.getDate();
            this.dob=day+"/"+month+"/"+year;

            this.email=response.email;
            this.aadharNo=response.aadharCardNo;
            this.phoneNo=response.phoneNo;
            this.panNo=response.pancardNo;
            this.photoPath=response.photoPath;
            this.empCode=response.empCode;
            if(response.gdata==0)
               this.genderData="MALE"
            if(response.gdata==1)
               this.genderData="FEMALE"

        })
    }

}

